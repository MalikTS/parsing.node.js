// import cherio from "cherio";
// import chalk from "chalk";
// import arrayFromLength from './pars'

// const SITE = 'https://auto.ru/catalog/cars/?page='
// const page = 10;


// (async function main() {
//     try {
//         for(const page of arrayFromLength(8)){
//             const url = `${SITE}${page}`
//             const pageContent = await getPageContent(url)
//         }
//     } catch (e) {
//         console.log(e);
//         console.log(e.message);
//     }
// })();




(async function () {
    try {
        let url = 
        "https://api.rss2json.com/v1/api.json?rss_url=https://www.vedomosti.ru/rss/rubric/business"


        fetch(url).then(respons => respons.json()).then(data =>{

            const info = data.items.map((item)=>{
                return item
            })

            console.log(info);
        })
    } catch (error) {
        console.log(error);
        console.log(error.message);
    }
   

})()



// (async () => {
//     try {
//       const url = "https://api.rss2json.com/v1/api.json?rss_url=https://www.vedomosti.ru/rss/rubric/business";
//       const response = await fetch(url);
//       const data = await response.json();
  
//       if (data.status === 'ok') {
//         console.log(data.items[0]); // первая новость
//       }
//     } catch (error) {
//       console.error(error.message);
//     }
//   })();