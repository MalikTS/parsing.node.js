import puppeteer from "puppeteer";

export async function getPageContent(url) {
    
}