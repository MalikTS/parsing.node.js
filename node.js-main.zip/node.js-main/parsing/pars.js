export  function arrayFromLength(){

    return Array.from(new Array(number).keys()).map((key)=>{
        return k + 1
    })
}